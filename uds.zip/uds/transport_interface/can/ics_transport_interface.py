"""
ics_transport_interface.py

Attempt to fix recurring issues:
 - Provide all required args to CanPacketRecord(...) so it doesn't throw TypeError.
 - Skip "invalid single-frame" frames where nibble=0 but length=8 (sf_dl>7).
 - Ensure fallback single-frame is given a list of bytes, not a UdsMessage.
 - Acknowledge device limitation if ICS says 'neoVI tx not supported.'.
"""

import time
import logging
import threading
import ctypes
from queue import Queue, Empty
from typing import Any, Optional
import asyncio

try:
    import ics
    ICS_AVAILABLE = True
except ImportError:
    ICS_AVAILABLE = False

from uds.transport_interface.abstract_transport_interface import AbstractTransportInterface
from uds.packet.can.can_packet import CanPacket
from uds.packet.can.can_packet_record import CanPacketRecord
from uds.packet.can.can_packet_type import CanPacketType
from uds.packet.can.can_packet_record import IsoTpDirection  # or wherever IsoTpDirection is defined
from uds.segmentation.can_segmenter import CanSegmenter
from uds.can.flow_control import DefaultFlowControlParametersGenerator
from uds.can.addressing_format import CanAddressingFormat
from uds.transmission_attributes import AddressingType
from uds.message.uds_message import UdsMessageRecord

from uds.can.addressing_information import CanAddressingInformation


class IcsTransportInterface(AbstractTransportInterface):
    MAX_LOG_COUNT = 50

    def __init__(
        self,
        device=None,
        baudrate=500000,
        network_id=ics.NETID_HSCAN,
        enable_hw_iso_tp=False,
        hw_iso_tp_tx_id: Optional[int] = None,
        hw_iso_tp_rx_id: Optional[int] = None,
        flow_control_parameters=None,
        addressing_information=None,
        reinit_on_error: bool = False,
        periodic_status_interval: float = 0.0
    ):
        super().__init__(bus_manager=None)

        if not ICS_AVAILABLE:
            raise ImportError("python-ics is not installed. Cannot use IcsTransportInterface.")

        self.logger = logging.getLogger(__name__)
        self.baudrate = baudrate
        self.network_id = network_id
        self.enable_hw_iso_tp = enable_hw_iso_tp
        self.hw_iso_tp_tx_id = hw_iso_tp_tx_id if hw_iso_tp_tx_id is not None else 0x7E0
        self.hw_iso_tp_rx_id = hw_iso_tp_rx_id if hw_iso_tp_rx_id is not None else 0x7E8
        self.reinit_on_error = reinit_on_error
        self.periodic_status_interval = periodic_status_interval

        self._log_count = 0
        self._last_status_time = 0.0

        if flow_control_parameters is None:
            flow_control_parameters = DefaultFlowControlParametersGenerator(block_size=0, st_min=0)
        self.flow_control_params = flow_control_parameters

        if addressing_information is None:
            addressing_information = CanAddressingInformation(
                addressing_format=CanAddressingFormat.NORMAL_ADDRESSING
            )
        self.addressing_information = addressing_information

        self.device = None
        self._configure_and_open_device(device)

        self._segmenter = CanSegmenter(addressing_information=self.addressing_information)

        self._rx_stop = threading.Event()
        self._rx_queue = Queue()
        self._rx_thread = threading.Thread(target=self._rx_loop, daemon=True)
        self._rx_thread.start()

        self.logger.info(
            f"IcsTransportInterface ready. Device={self.device}, baud={baudrate}, "
            f"netID={network_id}, hw_iso_tp={enable_hw_iso_tp}"
        )

    # region AbstractTransportInterface

    @property
    def segmenter(self) -> CanSegmenter:
        return self._segmenter

    @staticmethod
    def is_supported_bus_manager(bus_manager: Any) -> bool:
        return bus_manager is None

    def send_packet(self, packet: CanPacket) -> CanPacketRecord:
        """
        Sends a raw CAN packet via ICS. 
        Must create a CanPacketRecord with the required 5 arguments:
         (packet, direction, addressing_type, addressing_format, transmission_time).
        """
        if not self.device:
            self.logger.warning("No device open; cannot send_packet.")
            return CanPacketRecord(
                can_packet=packet,
                direction=IsoTpDirection.TX,
                addressing_type=packet.addressing_type,
                addressing_format=packet.addressing_format,
                transmission_time=time.time()
            )

        # Build the ICS SpyMessage
        spy_msg = ics.SpyMessage()
        spy_msg.ArbIDOrHeader = packet.can_id
        spy_msg.NetworkID = self.network_id

        # ICS wants up to 8 bytes, pass them as a tuple
        data_list = list(packet.payload)
        if len(data_list) > 8:
            data_list = data_list[:8]
        while len(data_list) < 8:
            data_list.append(0)
        spy_msg.NumberBytesData = len(packet.payload) if len(packet.payload) <= 8 else 8
        spy_msg.Data = tuple(data_list)

        try:
            ics.transmit_messages(self.device, [spy_msg])
            self.logger.debug(
                "Sent packet ID=0x%X Data=%s",
                packet.can_id,
                bytes(packet.payload).hex()
            )
        except Exception as e:
            self.logger.error("Failed to transmit CAN packet: %s", e)
            # Either way, return a record with direction TX
            return CanPacketRecord(
                can_packet=packet,
                direction=IsoTpDirection.TX,
                addressing_type=packet.addressing_type,
                addressing_format=packet.addressing_format,
                transmission_time=time.time()
            )

        # Success path
        return CanPacketRecord(
            can_packet=packet,
            direction=IsoTpDirection.TX,
            addressing_type=packet.addressing_type,
            addressing_format=packet.addressing_format,
            transmission_time=time.time()
        )

    async def async_send_packet(self, packet: CanPacket, loop=None) -> CanPacketRecord:
        loop = loop or asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.send_packet, packet)

    def receive_packet(self, timeout: Optional[float] = None) -> CanPacketRecord:
        """
        Pull a single CAN frame from our RX queue. 
        Build a proper CanPacketRecord with direction=RX, etc.
        """
        to = timeout if timeout is not None else 1.0
        start_time = time.time()
        while time.time() - start_time < to:
            try:
                pkt = self._rx_queue.get_nowait()  # this 'pkt' is a CanPacket
                self.logger.debug("Returning queued packet ID=0x%X", pkt.can_id)
                return CanPacketRecord(
                    can_packet=pkt,
                    direction=IsoTpDirection.RX,
                    addressing_type=pkt.addressing_type,
                    addressing_format=pkt.addressing_format,
                    transmission_time=time.time()
                )
            except Empty:
                time.sleep(0.01)
        raise TimeoutError("Timeout waiting for a CAN packet in ICS transport.")

    async def async_receive_packet(self, timeout: Optional[float] = None, loop=None) -> CanPacketRecord:
        loop = loop or asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.receive_packet, timeout)

    def send_message(self, message) -> UdsMessageRecord:
        """
        Sends a UDS message. 
        If hardware ISO-TP is available, we use it; otherwise fallback to single-frame.
        """
        if not self.device:
            raise RuntimeError("send_message() failed; ICS device not open.")

        raw_payload = bytes(message.payload)

        # 1) Attempt hardware ISO-TP
        if self.enable_hw_iso_tp and hasattr(ics, "iso15765_transmit_message"):
            try:
                DataArrayType = ctypes.c_ubyte * 4096
                iso_data = DataArrayType()
                for i, val in enumerate(raw_payload):
                    iso_data[i] = val

                tx_msg = ics.st_cm_iso157652_tx_message.st_cm_iso157652_tx_message()
                tx_msg.id = self.hw_iso_tp_tx_id
                tx_msg.vs_netid = self.network_id
                tx_msg.num_bytes = len(raw_payload)
                tx_msg.padding = 0xAA
                tx_msg.fc_id = self.hw_iso_tp_rx_id
                tx_msg.fc_id_mask = 0xFFF
                tx_msg.flowControlExtendedAddress = 0
                tx_msg.fs_timeout = 0x10
                tx_msg.fs_wait = 0x3000
                tx_msg.blockSize = 0
                tx_msg.stMin = 0
                tx_msg.paddingEnable = 1
                tx_msg.data = iso_data

                ics.iso15765_transmit_message(self.device, self.network_id, tx_msg, 3000)
                self.logger.info("HW ISO-TP transmit success.")
                return UdsMessageRecord(message)
            except Exception as e:
                self.logger.warning("HW ISO-TP transmit failed; fallback to single-frame. Error=%s", e)

        # 2) Single-frame fallback
        fallback_can_id = 0x7E0
        payload_list = list(raw_payload)
        if len(payload_list) > 7:
            self.logger.warning("Message payload >7 bytes; single-frame truncated to 7 bytes.")
            payload_list = payload_list[:7]

        dlc = 8
        pkt = CanPacket(
            packet_type=CanPacketType.SINGLE_FRAME,
            addressing_format=CanAddressingFormat.NORMAL_ADDRESSING,
            addressing_type=AddressingType.PHYSICAL,
            can_id=fallback_can_id,
            dlc=dlc,
            payload=payload_list
        )
        self.send_packet(pkt)
        self.logger.debug("Sent single-frame fallback with payload=%r, dlc=%d", payload_list, dlc)
        return UdsMessageRecord(message)

    async def async_send_message(self, message, loop=None) -> UdsMessageRecord:
        loop = loop or asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.send_message, message)

    def receive_message(self, timeout: Optional[float] = None) -> UdsMessageRecord:
        """If hardware ISO-TP is enabled, try iso15765_receive_message(); else fallback."""
        if not self.device:
            raise TimeoutError("receive_message() failed; ICS device not open.")

        if self.enable_hw_iso_tp and hasattr(ics, 'iso15765_receive_message'):
            try:
                rx_msg = ics.st_cm_iso157652_rx_message.st_cm_iso157652_rx_message()
                rx_msg.id = self.hw_iso_tp_tx_id
                rx_msg.vs_netid = self.network_id
                rx_msg.padding = 0xAA
                rx_msg.id_mask = 0xFFF
                rx_msg.fc_id = self.hw_iso_tp_rx_id
                rx_msg.blockSize = 100
                rx_msg.stMin = 10
                rx_msg.cf_timeout = 1000
                rx_msg.enableFlowControlTransmission = 1
                rx_msg.paddingEnable = 1

                ics.iso15765_receive_message(self.device, self.network_id, rx_msg)
                time.sleep(0.5)

                msgs, err_count = ics.get_messages(self.device)
                if msgs:
                    full_payload = b"".join(bytes(m.Data) for m in msgs)
                    self.logger.info("HW ISO-TP received message with %d bytes", len(full_payload))
                    return UdsMessageRecord(full_payload)
                else:
                    raise TimeoutError("No HW ISO-TP message received.")
            except Exception as e:
                self.logger.warning("HW ISO-TP receive failed, fallback to normal frames. %s", e)

        rec = self.receive_packet(timeout=timeout)
        # rec is a CanPacketRecord. Extract the underlying packet
        if rec.can_packet.packet_type == CanPacketType.SINGLE_FRAME:
            self.logger.info("Received single-frame UDS message (fallback).")
            return UdsMessageRecord(payload=rec.can_packet.payload)
        else:
            self.logger.debug("Received multi-frame type %s (fallback).", rec.can_packet.packet_type)
            return UdsMessageRecord(payload=rec.can_packet.payload)

    # endregion

    # region ICS Device Handling

    def _configure_and_open_device(self, existing_device=None):
        try:
            if existing_device is None:
                devs = ics.find_devices()
                if not devs:
                    raise RuntimeError("No ICS devices found.")
                self.device = devs[0]
            else:
                self.device = existing_device

            # Force close if open
            try:
                ics.close_device(self.device)
                time.sleep(1)
            except Exception as e:
                self.logger.warning(f"Error closing device before open: {e}")

            self.logger.debug(f"Using ICS device: {self.device}")
            try:
                ics.open_device(self.device)
                self.logger.debug("ICS device open success.")
            except ics.ics.RuntimeError as e:
                self.logger.warning(f"open_device() error: {e}")

            from uds.utilities.ics_device_interrogation import dump_device_info
            try:
                dev_info = dump_device_info(self.device)
                self.logger.info("Device Info:\n%s", dev_info)
            except Exception as e:
                self.logger.error("Error during device interrogation: %s", e)

            try:
                ics.set_bit_rate(self.device, self.baudrate, self.network_id)
                time.sleep(0.3)
            except Exception as e:
                self.logger.error(f"set_bit_rate() failed: {e}")
                errs = ics.get_error_messages(self.device)
                self.logger.error(f"ICS Device Errors: {errs}")
                raise

            if hasattr(ics, "go_online"):
                ics.go_online(self.device)
            else:
                self.logger.debug("No go_online method found; skipping.")

            if self.enable_hw_iso_tp and hasattr(ics, "iso15765_enable_networks"):
                ics.iso15765_enable_networks(self.device, self.network_id)
                time.sleep(0.3)
                self.logger.debug("Hardware ISO-TP enabled on net %d", self.network_id)

        except Exception as e:
            self.logger.error("Failed to configure/open ICS device: %s", e)
            self.device = None

    def close(self):
        self.logger.debug("Shutting down ICS transport.")
        self._rx_stop.set()
        self._rx_thread.join(timeout=1.0)

        if self.device:
            try:
                if hasattr(ics, 'close_device'):
                    ics.close_device(self.device)
                    self.logger.debug("ICS device closed successfully.")
            except Exception as e:
                self.logger.warning("Error closing ICS device: %s", e)
        self.logger.info("IcsTransportInterface closed.")

    # endregion

    # region RX Thread

    def _rx_loop(self):
        self.logger.debug("RX thread started.")
        while not self._rx_stop.is_set():
            if not self.device:
                time.sleep(0.05)
                continue

            try:
                msgs, error_count = ics.get_messages(self.device)
                if msgs:
                    for m in msgs:
                        pkt = self._convert_spy_to_can_packet(m)
                        if pkt is not None:
                            self._rx_queue.put(pkt)

                if error_count > 0:
                    errs = ics.get_error_messages(self.device)
                    for em in errs:
                        self.logger.warning("ICS error: %s", em)

                if (self.periodic_status_interval > 0 and
                    (time.time() - self._last_status_time) > self.periodic_status_interval):
                    self._check_and_log_status()
                    self._last_status_time = time.time()

                time.sleep(0.01)
            except ics.ics.RuntimeError as e:
                self.logger.error("ICS runtime error in RX loop: %s", e)
                if self.reinit_on_error:
                    self.logger.info("Reinit after ICS error in rx_loop.")
                    time.sleep(1.0)
                    self._configure_and_open_device(existing_device=self.device)
            except Exception as e:
                self.logger.error("Unknown error in RX loop: %s", e)
                time.sleep(0.1)

        self.logger.debug("RX thread exiting...")

    # endregion

    # region Helpers

    def _check_and_log_status(self):
        try:
            if hasattr(ics, 'get_device_status'):
                st = ics.get_device_status(self.device)
                self.logger.info("Periodic ICS status: %s", st)
            if hasattr(ics, 'get_error_messages'):
                errs = ics.get_error_messages(self.device)
                for em in errs:
                    self.logger.warning("Periodic ICS error: %s", em)
        except Exception as e:
            self.logger.error("check_and_log_status error: %s", e)

    def _convert_spy_to_can_packet(self, spy_msg):
        """
        Convert ics.SpyMessage -> CanPacket if it appears to be valid UDS.
        We also skip single-frame nibble=0 frames that have 8 bytes (sf_dl>7).
        """
        try:
            raw_bytes = bytes(spy_msg.Data)
            self.logger.debug(
                "SpyMessage received: ArbID=0x%X, NetID=%s, Data=%s",
                spy_msg.ArbIDOrHeader, spy_msg.NetworkID, raw_bytes.hex()
            )
        except Exception as log_e:
            self.logger.error("Failed to log spy message: %s", log_e)
            return None

        # Skip TX loopback
        if spy_msg.StatusBitField & ics.SPY_STATUS_TX_MSG:
            return None

        raw_data = tuple(spy_msg.Data)
        if not raw_data:
            return None

        nibble = (raw_data[0] >> 4) & 0xF
        do_log = (self._log_count < self.MAX_LOG_COUNT)

        if nibble == 0:
            # Single frame nibble
            sf_dl = raw_data[0] & 0xF
            if sf_dl > 7:
                # This is a "bad" single-frame per ISO 15765
                if do_log:
                    self.logger.debug("Skipping invalid SingleFrame with sf_dl=%d, raw=%s", sf_dl, raw_data)
                self._increment_log_count()
                return None
            ptype = CanPacketType.SINGLE_FRAME
        elif nibble == 1:
            ptype = CanPacketType.FIRST_FRAME
        elif nibble == 2:
            ptype = CanPacketType.CONSECUTIVE_FRAME
        elif nibble == 3:
            ptype = CanPacketType.FLOW_CONTROL
        else:
            # not recognized as UDS
            if do_log:
                self.logger.debug("Skipping non-UDS nibble=0x%X data=%s", nibble, raw_data)
            self._increment_log_count()
            return None

        try:
            pkt = CanPacket(
                packet_type=ptype,
                addressing_format=CanAddressingFormat.NORMAL_ADDRESSING,
                addressing_type=AddressingType.PHYSICAL,
                can_id=spy_msg.ArbIDOrHeader,
                dlc=len(raw_data),
                payload=raw_data
            )
            return pkt
        except Exception as e:
            if do_log:
                self.logger.error("Failed build CanPacket: %s. nibble=0x%X data=%s", e, nibble, raw_data)
            self._increment_log_count()
            return None

    def _increment_log_count(self):
        self._log_count += 1
        if self._log_count == self.MAX_LOG_COUNT:
            self.logger.info(f"Hit log limit of {self.MAX_LOG_COUNT}; further logs suppressed.")

    # endregion
